﻿using System;
using System.Collections.Generic;

namespace WPSPApi.Models
{
    public partial class Course
    {
        public string Type { get; set; }
    }
}
