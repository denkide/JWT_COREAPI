﻿using System;
using System.Collections.Generic;

namespace WPSPApi.Models
{
    public partial class Patroltype
    {
        public int PatrolTypeId { get; set; }
        public string PatrolType1 { get; set; }
    }
}
