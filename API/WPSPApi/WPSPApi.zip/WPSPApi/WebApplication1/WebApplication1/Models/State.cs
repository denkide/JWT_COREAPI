﻿using System;
using System.Collections.Generic;

namespace WPSPApi.Models
{
    public partial class State
    {
        public int StateId { get; set; }
        public string State1 { get; set; }
    }
}
