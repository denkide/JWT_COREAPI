﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WPSPApi.DataProvider;
using WPSPApi.Models;

namespace WPSPApi.Controllers
{
    //[Produces("application/json")]
    [Route("api/Patroller")]
    public class PatrollerController : Controller
    {
        private IPatrollerDataProvider patrollerDataProvider;

        public PatrollerController(IPatrollerDataProvider patrollerDataProvider)
        {
            this.patrollerDataProvider = patrollerDataProvider;
        }

        [HttpGet]
        public async Task<IEnumerable<Patroller>> Get()
        {
            return await this.patrollerDataProvider.GetPatrollers();
        }

        [HttpGet("{id}")]
        public async Task<Patroller> Get(int UserId)
        {
            return await this.patrollerDataProvider.GetPatroller(UserId);
        }

        [HttpPost]
        public async Task Post([FromBody]Patroller patroller)
        {
            await this.patrollerDataProvider.AddPatroller(patroller);
        }

        [HttpPut("{id}")]
        public async Task Put(int skiPatrolNumber, [FromBody]Patroller patroller)
        {
            await this.patrollerDataProvider.UpdatePatroller(patroller);
        }

        [HttpDelete("{id}")]
        public async Task Delete(int skiPatrolNumber)
        {
            await this.patrollerDataProvider.DeletePatroller(skiPatrolNumber);
        }
    }
}